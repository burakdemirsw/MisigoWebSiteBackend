﻿namespace GoogleAPI.Domain.Models.Cargo.Mng.Order
{
    public class OrderPieceList_MNG
    {
        public string? Barcode { get; set; }
        public int Desi { get; set; }
        public int Kg { get; set; }
        public string? Content { get; set; }
    }

}
